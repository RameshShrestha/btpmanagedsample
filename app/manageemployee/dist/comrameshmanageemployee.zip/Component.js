sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("com.ramesh.manageemployee.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map